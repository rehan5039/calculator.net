=== BMI Calculator ===
Contributors: calculator.net
Tags: bmi, body mass index, calculator, body weight, widget, widgets, plugin, sidebar, health
Requires at least: 2.5
Tested up to: 4.8
Stable tag: 1.2

This BMI calculator can give out the BMI value as well as basic understandings based on age, height, and weight.

== Description ==

This BMI calculator can give out the BMI value as well as basic understandings based on age, height, and weight. It accepts both the units for the United States and the metric units. This calculator can be inserted either to the sidebar or into the post, but not both. Check http://www.calculator.net/bmi-calculator.html for a demo of this calculator.

== Installation ==

1. Unzip "bmi-calculator-wp-widget-1.2.zip" and upload the contained files to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress

= Add this calculator to sidebar =

1. Install "BMI Calculator" through the WordPress admin menu of Appearance or Design and then widgets.

= Add this calculator to a post or a page =

1. Place [calculatornet_bmi_calculator] in the content to insert into a post.

== Frequently Asked Questions ==

= Can I change the look and feel of the calculator? =

Yes, you can edit the code after "Edit the following to change the look and feel of this calculator" in bmi-calculator-wp-widget.php to change the look and feel. You need to have basic HTML understanding to change it correctly.

= Can I put this calculator to both the sidebar and the post? =

No, please put it to either the sidebar or the post, but not both. If put into both places, the calculator will generate javascript error.

== Screenshots ==

1. This screen shot description corresponds to bmi-calculator.gif.