=== Math Calculator ===
Contributors: calculator.net
Tags: calculator, math calculator, widget, widgets, plugin, sidebar
Requires at least: 2.5
Tested up to: 4.8
Stable tag: 1.2

This calculator can be used for quick on site calculations.

== Description ==

This calculator can be used for quick on site calculations. Check http://www.calculator.net/math-calculator.html for a demo of this calculator.

== Installation ==

1. Unzip "math-calculator-wp-widget-1.2.zip" and upload the contained files to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress
3. Install "Math Calculator" through the WordPress admin menu of Appearance or Design and then widgets.

== Frequently Asked Questions ==

= Can I change the look and feel of the calculator? =

Yes, you can edit the code after "Edit the following to change the look and feel of this calculator" in math-calculator-wp-widget.php to change the look and feel. You need to have basic HTML understanding to change it correctly.

== Screenshots ==

1. This screen shot description corresponds to math-calculator.gif.