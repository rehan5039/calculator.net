=== Mortgage Loan Calculator ===
Contributors: calculator.net
Tags: mortgage calculator, loan calculator, calculator, mortgage payment calculator, real estate, personal finance, widget, widgets, plugin, sidebar
Requires at least: 2.5
Tested up to: 4.8
Stable tag: 1.2

A standard mortgage loan calculator to calculate the monthly mortgage payments, total payments, and interest.

== Description ==

A standard mortgage loan calculator to calculate the monthly mortgage payments, total payments, and interest based on the loan amount, interest rate, loan term, etc. This calculator can be inserted either to the sidebar or into the post, but not both.

== Installation ==

1. Unzip "mortgage-calculator-wp-widget-1.2.zip" and upload the contained files to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress

= Add this calculator to sidebar =

1. Install "Mortgage Loan Calculator" through the WordPress admin menu of Appearance or Design and then widgets.

= Add this calculator to a post or a page =

1. Place [calculatornet_mortgage_calculator] in the content to insert into a post.

== Frequently Asked Questions ==

= Can I change the look and feel of the calculator? =

Yes, you can edit the code after "Edit the following to change the look and feel of this calculator" in mortgage-calculator-wp-widget.php to change the look and feel. You need to have basic HTML understanding to change it correctly.

= Can I put this calculator to both the sidebar and the post? =

No, please put it to either the sidebar or the post, but not both. If put into both places, the calculator will generate javascript error.

== Screenshots ==

1. This screen shot description corresponds to mortgage-loan-calculator.gif.